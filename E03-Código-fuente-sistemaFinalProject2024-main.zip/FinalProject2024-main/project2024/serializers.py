import random
import string
from rest_framework import serializers
from django.core.mail import send_mail
from django.contrib.auth.hashers import check_password
from django.utils.translation import gettext as _
from .models import Curso, Pago, Inscripcion, Estudiante,Docente, Administrativo, HistorialPago, Reembolso, Notificacion, Reporte


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class AdministrativoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Administrativo
        fields = [
            'id', 'nombre_completo', 'cedula', 'correo', 'telefono', 'celular',
            'direccion', 'estado', 'departamento', 'cargo', 'fecha_ingreso',
            'codigo_adm', 'acceso'
        ]

    def create(self, validated_data):
        # Generar una contraseña aleatoria
        password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
        validated_data['password'] = password

        # Crear el usuario administrativo
        administrativo = Administrativo.objects.create(**validated_data)

        # Enviar correo electrónico con las credenciales
        send_mail(
            subject='Cuenta Administrativa Creada',
            message=(
                f"Hola {administrativo.nombre_completo},\n\n"
                f"Tu cuenta administrativa ha sido creada exitosamente.\n"
                f"Código de acceso: {administrativo.codigo_adm}\n"
                f"Contraseña: {password}\n\n"
                f"Por favor, actualiza tu contraseña una vez inicies sesión."
            ),
            from_email='wilberthvers07@gmail.com',  # Cambiar por la dirección de correo correspondiente
            recipient_list=[administrativo.correo],
            fail_silently=False,
        )

        return administrativo


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class DocenteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Docente
        fields = [
            'id', 'nombre_completo', 'cedula', 'correo', 'telefono', 'celular',
            'direccion', 'estado', 'especialidad', 'fecha_contratacion',
            'facultad', 'escuela', 'campus', 'codigo_doc', 'estatus', 'codigo'
        ]

    def create(self, validated_data):
        # Generar una contraseña aleatoria
        password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
        validated_data['password'] = password

        # Crear el docente
        docente = Docente.objects.create(**validated_data)

        # Enviar correo electrónico con las credenciales
        send_mail(
            subject='Cuenta de Docente Creada',
            message=f"Hola {docente.nombre_completo},\n\n"
                    f"Tu cuenta ha sido creada exitosamente.\n"
                    f"Tu código de acceso es: {docente.codigo_doc}\n"
                    f"Tu contraseña es: {password}\n\n"
                    f"Por favor, actualiza tu contraseña después de iniciar sesión.",
            from_email='wilberthvers07@gmail.com',  # Cambia esto por tu dirección de correo
            recipient_list=[docente.correo],
            fail_silently=False,
        )

        return docente


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class CursoSerializer(serializers.ModelSerializer):
    profesor = serializers.SerializerMethodField()

    class Meta:
        model = Curso
        fields = '__all__'

    def get_profesor(self, obj):
        return None


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class PagoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pago
        fields = '__all__'

    def validate(self, data):
        if data['monto'] <= 0:
            raise serializers.ValidationError(_("El monto debe ser mayor que cero."))
        return data

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['monto'] = self.formatear_monto(instance.monto)
        return representation

    @staticmethod
    def formatear_monto(monto):
        """
        Formatea el monto en pesos dominicanos (DOP).
        """
        return f"RD${monto:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')



""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class HistorialPagoSerializer(serializers.ModelSerializer):
    pago = PagoSerializer()  # Define el serializer para el pago anidado

    class Meta:
        model = HistorialPago
        fields = ['pago', 'estado_pago_anterior', 'estado_pago_nuevo', 'fecha_cambio', 'comentario']
        read_only_fields = ['fecha_cambio']  # Este campo se genera automáticamente y no debe ser modificado

    def create(self, validated_data):
        # Extraer los datos del pago del serializer anidado
        pago_data = validated_data.pop('pago')
        
        # Crear el pago relacionado con este historial de pago
        pago = Pago.objects.create(**pago_data)
        
        # Crear el historial de pago usando el pago recién creado
        historial_pago = HistorialPago.objects.create(pago=pago, **validated_data)
        
        return historial_pago

    def update(self, instance, validated_data):
        # Actualizar el pago si es necesario
        pago_data = validated_data.pop('pago', None)
        
        if pago_data:
            # Si se proporciona un pago anidado, actualízalo
            instance.pago.monto = pago_data.get('monto', instance.pago.monto)
            instance.pago.estado_pago = pago_data.get('estado_pago', instance.pago.estado_pago)
            instance.pago.save()
        
        # Actualizar los demás campos del historial de pago
        instance.estado_pago_anterior = validated_data.get('estado_pago_anterior', instance.estado_pago_anterior)
        instance.estado_pago_nuevo = validated_data.get('estado_pago_nuevo', instance.estado_pago_nuevo)
        instance.fecha_cambio = validated_data.get('fecha_cambio', instance.fecha_cambio)
        instance.comentario = validated_data.get('comentario', instance.comentario)
        
        instance.save()
        return instance


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class ReembolsoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reembolso
        fields = ['id', 'usuario', 'pago', 'motivo', 'estado', 'fecha_solicitud', 'fecha_resolucion']
        read_only_fields = ['fecha_solicitud', 'fecha_resolucion']
    
    def update(self, instance, validated_data):
        # Aquí puedes agregar lógica adicional para actualizar el estado del reembolso
        instance.estado = validated_data.get('estado', instance.estado)
        instance.fecha_resolucion = validated_data.get('fecha_resolucion', instance.fecha_resolucion)
        instance.save()
        return instance
    

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class NotificacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notificacion
        fields = ['id', 'usuario', 'tipo_notificacion', 'mensaje', 'fecha_envio', 'estado']
        read_only_fields = ['fecha_envio']  # Solo se establece automáticamente en el envío
    
    def validate(self, data):
        # Validación personalizada si es necesario
        return data


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class InscripcionSerializer(serializers.ModelSerializer):
    nombre_curso = serializers.ReadOnlyField(source='curso.nombre') 

    class Meta:
        model = Inscripcion
        fields = '__all__'


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

class EstudianteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Estudiante
        fields = [
            'id','nombre_completo', 'cedula', 'correo', 'telefono', 'celular',
            'direccion', 'estado', 'matricula'
        ]

    def create(self, validated_data):
        # Generar una contraseña aleatoria
        password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
        validated_data['password'] = password

        # Crear el estudiante
        estudiante = Estudiante.objects.create(**validated_data)

        # Enviar el correo electrónico con la contraseña
        send_mail(
            subject='Tu cuenta ha sido creada',
            message=f"Hola {estudiante.nombre_completo},\n\nTu cuenta ha sido creada exitosamente. Tu contraseña es: {password}\n\nPor favor, cámbiala una vez inicies sesión.",
            from_email='wilberthvers07@gmail.com',  # Cambia esto por tu dirección de correo electrónico
            recipient_list=[estudiante.correo],
            fail_silently=False,
        )

        return estudiante


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class AdministrativoAccesoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Administrativo
        fields = ['password', 'acceso', 'codigo_adm']  # El campo 'correo' se elimina
        extra_kwargs = {
            'password': {'write_only': True}  # Oculta el campo 'password' en las respuestas
        }


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class UserAuthSerializer(serializers.Serializer):
    password = serializers.CharField(write_only=True)
    codigo_doc = serializers.CharField(required=False, allow_blank=True)
    codigo_adm = serializers.CharField(required=False, allow_blank=True)
    matricula = serializers.CharField(required=False, allow_blank=True)

    def validate(self, attrs):
        # Verificamos que al menos uno de los campos de identificador esté presente
        if not any([attrs.get('codigo_doc'), attrs.get('codigo_adm'), attrs.get('matricula')]):
            raise serializers.ValidationError("Debe proporcionar al menos un código docente, administrativo o matrícula.")
        return attrs


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class ReporteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reporte
        fields = ['id', 'tipo_reporte', 'fecha_generacion', 'descripcion']
        read_only_fields = ['fecha_generacion']  # Solo lectura, se genera automáticamente

    def validate(self, data):
        # Validación adicional si es necesaria
        return data
    


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


class ResetPasswordSerializer(serializers.Serializer):
    correo = serializers.EmailField()
    identificador = serializers.CharField(max_length=20)

    def validate(self, data):
        correo = data.get('correo')
        identificador = data.get('identificador')

        # Intentamos obtener el usuario en una sola operación optimizada
        usuario = Estudiante.objects.filter(correo=correo, matricula=identificador).first() or \
                 Docente.objects.filter(correo=correo, codigo_doc=identificador).first() or \
                 Administrativo.objects.filter(correo=correo, codigo_adm=identificador).first()

        # Verificamos si el usuario fue encontrado
        if not usuario:
            raise serializers.ValidationError({"detail": "Usuario no encontrado con los datos proporcionados."})

        # Si se encontró un usuario, lo agregamos a los datos validados
        data['usuario'] = usuario
        return data


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

class UpdatePasswordSerializer(serializers.Serializer):
    """
    Serializer para actualizar la contraseña de un usuario administrativo (sin seguridad).
    """
    username = serializers.CharField(required=True)
    password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        # Validar si el usuario administrativo existe
        try:
            user = Administrativo.objects.get(codigo_adm=username)
        except Administrativo.DoesNotExist:
            raise serializers.ValidationError("Administrativo no encontrado.")

        # Validar contraseña actual sin encriptación
        if user.password != password:
            raise serializers.ValidationError("Contraseña actual incorrecta.")

        data['user'] = user
        return data
