from django.apps import AppConfig


class Project2024Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project2024'
